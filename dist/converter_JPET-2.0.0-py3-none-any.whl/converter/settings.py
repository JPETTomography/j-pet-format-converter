#Modules settings
#Author: Mateusz Kruk
#E-mail: mateusz64.kruk@student.uj.edu.pl

CASToR_VERSION = '3.1'
TEST_DIR = "/tmp/i2d_test"

# Root UID obtained from (http://www.medicalconnections.co.uk/FreeUID.html)
UID = '1.2.826.0.1.3680043.10.837.'